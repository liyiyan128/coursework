import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private int dimension;
    private WeightedQuickUnionUF UF;
    private WeightedQuickUnionUF fullSites;
    private boolean[][] sites;
    private int topSite = 0;
    private int bottomSite = 0;
    private int openSites = 0;

    // create n by n grid with all sites initially blocked
    public Percolation(int n) {
        if (n < 1) {throw new IllegalArgumentException();}  // corner case
        
        dimension = n;
        UF = new WeightedQuickUnionUF(n * n + 2);  // introduce two virtual sites (top/bottom)
        fullSites = new WeightedQuickUnionUF(n * n + 1);
        topSite = n * n;
        bottomSite = n * n + 1;
        sites = new boolean[n][n];
    } 

    // open site(row, col)
    public void open(int row, int col) {
        check(row, col);

        if (isOpen(row, col)) return;

        int index = index(row, col);

        // top adjacent site
        if (row == 1) {
            UF.union(index, topSite);
            fullSites.union(index, topSite);
        }else{
            int topRow = row - 1;
            unionIfOpen(topRow, col, index);
        }

        // bottom adjacent site
        if (row == dimension) {
            UF.union(index, bottomSite);
        }else {
            int bottomRow = row + 1;
            unionIfOpen(bottomRow, col, index);
        }

        // right adjacent site
        if (col < dimension) {
            int rightCol = col + 1;
            unionIfOpen(row, rightCol, index);
        }

        // left adjacent site
        if  (col > 1) {
            int leftCol = col - 1;
            unionIfOpen(row, leftCol, index);
        }

        sites[row - 1][col - 1] = true;
        openSites++;
    }


    // is site(row, col) open?
    public boolean isOpen(int row, int col) {
        check(row, col);

        return sites[row - 1][col - 1] == true;
    }


    // is site(row, col) full?
    public boolean isFull(int row, int col) {
        check(row, col);

        int index = index(row, col);
        return fullSites.connected(index, topSite);
    }


    // return number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }


    // does the system percolate?
    public boolean percolates() {
        return UF.connected(topSite, bottomSite);
    }
    

    private int index(int row, int col) {
        return dimension * (row - 1) + (col - 1);
    }


    private void check(int row, int col) {
        if (row < 1 || row > dimension || col < 1 || col > dimension) {
            throw new IllegalArgumentException();
        }
    }

    
    private void unionIfOpen(int row, int col, int unionIndex) {
        if (isOpen(row, col)) {
            int index = index(row, col);
            UF.union(index, unionIndex);
            fullSites.union(index, unionIndex);
        }
    }
}
